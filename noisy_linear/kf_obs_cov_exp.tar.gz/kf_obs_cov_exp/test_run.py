# This is a test script for the hypothesis on the transient growth rates
from kf_obs_exp import experiment

completed = experiment([200,8,10])

print(completed)

########################################################################################################################
